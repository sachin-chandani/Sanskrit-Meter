package mi;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MeterIdentification {
	public String gana_pat[] = { "lgg", "glg", "ggl", "gll", "lgl", "llg", "lll", "ggg" };
	public String gana_name[] = { "y", "r", "t", "B", "j", "s", "n", "m" };
	public String syllables[] = new String[500];
	public String longstring;
	public int num_metre = 1000;
	public String sama_name[] = new String[num_metre];
	public String sama_pat[] = new String[num_metre];
	public int numSylVerse = 0;
	public int sama_entered = 0;
	public int numPatterns = 0;
	public String pats[] = new String[num_metre];
	public String ardha_metre[] = new String[num_metre];
	public String ardha_pat[] = new String[num_metre];
	public int ardh_entered = 0;
	public String visama_metre[] = new String[num_metre];
	public String visama_pat[] = new String[num_metre];
	public int visama_entered = 0;
	public String upajati_metre[] = new String[num_metre];
	public String upajati_pat[] = new String[num_metre];
	public int upajAti_entered = 0;
	public int arya_entered = 0;
	public String arya_metre[] = new String[num_metre];
	public String arya_pat[] = new String[num_metre];
	public int num_matra_regex = 0;
	public String matra_regex[] = new String[num_metre];
	public String matra_pat_all[] = new String[num_metre];
	public String orig_input = "";
	public int radio_input = 3;
	public StringBuilder output = new StringBuilder();

	@SuppressWarnings("unused")
	
	public String process(String verse, int radio, String code) throws Exception {
		// System.out.println("beginning " + verse);
		BufferedReader brm = new BufferedReader(new FileReader("../webapps/mitweb/samavftta.txt"));
		// ..//webapps//Verse//
		String s = "";
		while ((s = brm.readLine()) != null) {
			String tmp[] = s.trim().split(" ");
			sama_name[sama_entered] = tmp[0];
			sama_pat[sama_entered] = tmp[1];
			if (tmp.length > 2) {
				if (tmp[2].equals("vA")) {
					pats[numPatterns] = tmp[1];// this takes vA;
					numPatterns++;
				} else {
					output.append("Error in input: " + s);
				}
			}
			sama_entered++;
		}
		brm.close();
		brm = new BufferedReader(new FileReader("../webapps/mitweb/arDasama.txt"));
		while ((s = brm.readLine()) != null) {
			String tmp[] = s.trim().split(" ");
			ardha_metre[ardh_entered] = tmp[0];
			ardha_pat[ardh_entered] = "";
			for (int i = 1; i < tmp.length; i++) {
				if (tmp[i].equals("vA")) {
					pats[numPatterns] = tmp[i - 1];
					numPatterns++;
				} else {
					ardha_pat[ardh_entered] += " " + tmp[i];
				}
			}
			ardha_pat[ardh_entered] = ardha_pat[ardh_entered].trim();
			ardh_entered++;
		}
		brm.close();
		brm = new BufferedReader(new FileReader("../webapps/mitweb/vizama.txt"));
		while ((s = brm.readLine()) != null) {
			String tmp[] = s.trim().split(" ");
			visama_metre[visama_entered] = tmp[0];
			visama_pat[visama_entered] = "";
			for (int i = 1; i < tmp.length; i++) {
				if (tmp[i].equals("vA")) {
					pats[numPatterns] = tmp[i - 1];
					numPatterns++;
				} else {
					visama_pat[visama_entered] += " " + tmp[i];
				}
			}
			visama_pat[visama_entered] = visama_pat[visama_entered].trim();
			visama_entered++;
		}
		brm.close();
		brm = new BufferedReader(new FileReader("../webapps/mitweb/upajAti.txt"));
		while ((s = brm.readLine()) != null) {
			String tmp[] = s.trim().split(" ");
			upajati_metre[upajAti_entered] = tmp[0];
			upajati_pat[upajAti_entered] = "";
			for (int i = 1; i < tmp.length; i++) {
				if (tmp[i].equals("vA")) {
					pats[numPatterns] = tmp[i - 1];
					numPatterns++;
				} else {
					upajati_pat[upajAti_entered] += " " + tmp[i];
				}
			}
			upajati_pat[upajAti_entered] = upajati_pat[upajAti_entered].trim();
			upajAti_entered++;
		}
		brm.close();
		brm = new BufferedReader(new FileReader("../webapps/mitweb/AryA_metre.txt"));
		while ((s = brm.readLine()) != null) {
			String tmp[] = s.trim().split(" ");
			arya_metre[arya_entered] = tmp[0];
			arya_pat[arya_entered] = "";
			for (int i = 1; i < tmp.length; i++) {
				if (!tmp[i].equals("vA")) {
					arya_pat[arya_entered] += " " + tmp[i];
					matra_pat_all[num_matra_regex] = tmp[i];
					boolean optional_vA = false;
					if (i < tmp.length - 1) {
						if (tmp[i + 1].equals("vA")) {
							optional_vA = true;
						}
					}
					matra_regex[num_matra_regex] = make_regex_matra(tmp[i], optional_vA);
					// System.out.println( matra_regex[num_matra_regex]);
					num_matra_regex++;
				}
			}
			arya_pat[arya_entered] = arya_pat[arya_entered].trim();

			arya_entered++;
		}
		brm.close();

		String longString = "";

		if (code.equals("roman")) {
			System.out.println("paropakārāya = " + verse);
			longString = r2s(verse);
		} else {
			longString = verse;
		}

		int vC = 0;
		// while((si=br.readLine())!=null){
		radio_input = radio;// output should depend on its input
		/*
		 * 1 a single pada, 2. or two padas 3. or full verse 4. or more than one
		 * verse 5. or verse with extra text.
		 */
		numSylVerse = 0;
		vC++;
		// String longString = si.replace(" ", " ");
		if (code.equals("slp1")) {
			output.append("<br><font color=black>" + s2r(longString) + "</font>" + "<br>");
		} else {
			output.append("<br><font color=black>" + longString + "</font>" + "<br>");
		}

		output.append("<br><b>Meter details:</b>");
		// br.close();
		// === preprocessing to remove spaces etc. ====//
		Pattern p = Pattern.compile("[^a-zA-Z\\.]+");
		Matcher m = p.matcher(longString);
		Matcher m2 = p.matcher(verse);
		StringBuffer sb = new StringBuffer(5000);
		StringBuffer sb2 = new StringBuffer(5000);
		while (m.find()) {
			m.appendReplacement(sb, Matcher.quoteReplacement(""));
		}
		m.appendTail(sb);
		while (m2.find()) {
			m2.appendReplacement(sb2, Matcher.quoteReplacement(""));
		}
		m2.appendTail(sb2);

		longString = sb.toString();
		// verse = sb2.toString();

		// === preprocessing to remove spaces etc. ====//

		String firstLine = "";
		String secondLine = "";
		boolean isFound = false;
		int indexDot = longString.indexOf(".");
		int indexDouble = longString.indexOf("..");

		String metre_here = "none_found";
		if ((indexDot > 0) && (indexDouble > indexDot) && (radio_input == 3)) {// full
			// verse
			// case
			firstLine = longString.substring(0, longString.indexOf("."));
			secondLine = longString.substring(longString.indexOf(".") + 1, longString.lastIndexOf(".."));
			try {
				metre_here = main_metre(firstLine, secondLine, output);
			} catch (IOException e) {
				e.printStackTrace();
			}
			if (!(metre_here.equals("none_found"))) {
				isFound = true;
			}
			// output.append(" " + metre_here);

		} else {// Assume that no dots are provided
			longString = longString.replace(".", "");
			if ((radio_input == 1) || (radio_input == 2)) {// only one pada is
				// provided
				orig_input = longString;
				System.out.println("Radio input ..." + radio_input);
				firstLine = longString;
				secondLine = firstLine;
				try {
					metre_here = main_metre(firstLine, secondLine, output);
					System.out.println(firstLine + "\t" + secondLine + "\t" + metre_here);
				} catch (IOException e) {
					e.printStackTrace();
				}
				if (!(metre_here.equals("none_found"))) {
					isFound = true;
					// output.append(" " + metre_here);
					// fr.write(metre_here);
				}
			} else if (radio_input == 3) {
				int numSyls = regexChecker("[yvrlYmNRnJBGQDjbgqdKPCWTcwtkpSzsh]*[aAiIuUfFxXeEoO][HM]*", longString);
				int sylInds[] = sylInd("[yvrlYmNRnJBGQDjbgqdKPCWTcwtkpSzsh]*[aAiIuUfFxXeEoO][HM]*", longString,
						numSyls);
				loopO: for (int k = 0; k < numSyls - 1; k++) {
					numSylVerse = 0;
					firstLine = longString.substring(0, sylInds[k + 1]);
					secondLine = longString.substring(sylInds[k + 1]);
					try {
						metre_here = main_metre(firstLine, secondLine, output);
					} catch (IOException e) {
						e.printStackTrace();
					}
					if (!(metre_here.equals("none_found"))) {
						isFound = true;
						// output.append(" " + metre_here);
						// fr.write(metre_here);
						break loopO;
					}
				}
			}
		}
		if (!isFound) {// check if some other words are present as well
			if (radio_input == 5) {
				boolean toCont = true;
				while (toCont) {
					toCont = false;
					int numSyls = regexChecker("[yvrlYmNRnJBGQDjbgqdKPCWTcwtkpSzsh]*[aAiIuUfFxXeEoO][HM]*", longString);
					// System.out.println(numSyls);
					if (numSyls >= 16) {
						int sylInds[] = sylInd("[yvrlYmNRnJBGQDjbgqdKPCWTcwtkpSzsh]*[aAiIuUfFxXeEoO][HM]*", longString,
								numSyls);
						loopOO: for (int j = 0; j < numSyls - 1; j++) {// starting
							for (int k = j + 1; k < numSyls; k++) {// end
								loopO: for (int i = j; i < k - 1; i++) {
									if ((i - j >= 15) && (k - i >= 15)) {
										numSylVerse = 0;
										firstLine = longString.substring(sylInds[j], sylInds[i + 1]);
										secondLine = longString.substring(sylInds[i + 1], sylInds[k]);
										try {
											metre_here = main_metre(firstLine, secondLine, output);
										} catch (IOException e) {
										}
										if (!(metre_here.equals("none_found"))) {
											isFound = true;
											output.append(" " + metre_here + "\t");
											// fr.write(metre_here + "\t");

											// System.out.println(longString);
											// fr.write(longString+"\n");
											break loopOO;
										}
									}
								}
							}
						}
					}
				}
			} else if (radio_input == 4) {
				String first = "", second = "";
				int count = 0;
				Pattern pp = Pattern.compile("\\.\\.");
				Matcher mm = p.matcher(verse);

				while (mm.find()) {
					count += 1;
				}
				System.out.println(count);
				for (int i = 0; i < count; i++) {
					if (verse.length() > 0) {
						System.out.println("\n-------------------------\n" + i + "Length " + verse.length());
						System.out.println(verse);
						first = verse.substring(0, verse.indexOf("."));
						second = verse.substring(verse.indexOf(".") + 1, verse.indexOf(".."));
						verse = verse.replaceAll("^[^\\.]*\\. [^\\.]*\\.\\.", "");
						first = first.replaceAll("^\\s", "");
						//System.out.println("first " + first + "\nsecond " + second);
						metre_here = main_metre(first, second, output);
						//output.append("-" + metre_here + "\n");
						System.out.print("-" + metre_here + "\n");

					}

				}

			}
		}

		return output.toString();
	}

	@SuppressWarnings({ "unused" })
	public String main_metre(String firstLine, String secondLine, StringBuilder output) throws Exception {
		System.out.println("first " + firstLine + "\nsecond " + secondLine);
		int numSyllable1 = regexChecker("[yvrlYmNRnJBGQDjbgqdKPCWTcwtkpSzsh]*[aAiIuUfFxXeEoO][HM]*", firstLine);
		int len_line1 = firstLine.length();
		String output_print = "";

		if ((radio_input == 1) || (radio_input == 2)) {
			int chars = 0;
			int lenSyl[] = new int[numSylVerse];
			for (int i = 0; i < numSyllable1; i++) {
				lenSyl[i] = syllables[i].length();
				chars += lenSyl[i];
			}
			if (chars < len_line1) {
				syllables[numSyllable1 - 1] += firstLine.substring(chars);
				chars = len_line1;
				lenSyl[numSyllable1 - 1] += len_line1 - chars;
			}
			if (radio_input == 1) {// only one pada
				int numSyllable = numSylVerse;
				String metre_pada[] = find_metre_pada(lenSyl, syllables, numSyllable, 0);
				if (metre_pada[0].length() > 0) {
					String first_tmp = metre_pada[0];
					output.append("\n" + ("<br>The verse is in " + cm(s2r(first_tmp))
							+ " meter which is a samavtta.\n"));

					for (int i = 0; i < 1; i++) {
						output.append("\n" + ("<br><br><b>Pāda " + (i + 1) + "..........</b>"));
						output.append(
								"\n" + ("<br>Syllables &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;&nbsp" + metre_pada[2]));
					}

					// return metre_pada[0];
				} else {// check for anuzwuB
					String pp1 = make_optional_regex("ytBrjm");
					String pp2 = make_optional_regex("ytBrnm");
					Pattern pat1 = Pattern.compile("^[lg]" + pp1 + pp2 + "[lg]$");
					Pattern pat2 = Pattern.compile("^[lg]" + pp1 + "lgl" + "[lg]$");
					Matcher ma = pat1.matcher(metre_pada[3]);
					Matcher ma2 = pat2.matcher(metre_pada[3]);
					boolean isPres = true;
					if (!ma.find() && !ma2.find()) {
						for (int i = 0; i < 1; i++) {

							output.append(("<br>Syllables &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;&nbsp;" + metre_pada[2]
									+ "<br>"));
						}
						output.append("<br><b>No meter found for this pattern. Please check for any errors.</b>\n");
						isPres = false;
					}
					if (isPres) {
						output.append("\n"
								+ ("<br>The pāda is in <b><font color=\"blue\">anuṣṭubh1 </font></b>meter which is a samavṛtta.\n"));

						for (int i = 0; i < 1; i++) {
							output.append("\n" + ("<br><br><b>Pāda " + (i + 1) + "..........\n</b>"));
							output.append("\n" + ("<br>Syllables &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;&nbsp;"
									+ metre_pada[2] + "\n"));
						}

						return "anuzwuB";
						// metre_found=true;
					}
				}
			} else {
				// two padas
				String metre_pada[][] = new String[2][4];
				if (numSyllable1 % 2 == 0) {// even number of syllables
					int numSyl_pada = numSyllable1 / 2;
					for (int pada = 0; pada < 2; pada++) {// 4 padas
						int start = numSyl_pada * pada;
						metre_pada[pada] = find_metre_pada(lenSyl, syllables, numSyl_pada, start);
						// System.out.println("pada " + pada + " " +
						// metre_pada[pada][2]+"\nmetre_name..."+metre_pada[pada][0]+"\n");
					}
				}
				
				boolean samavftta = true;
				for (int i = 0; i < 2; i++) {
					if (metre_pada[i][0].length() == 0) {
						samavftta = false;
					}
				}
				if (samavftta) {
					// atleast some meter found for all padas
					String first_metre = metre_pada[0][0];
					String first_tmp = s2r(first_metre);
					// System.out.println(first_metre+"..."+first_metre);
					for (int i = 1; i < 2; i++) {
						if (!(metre_pada[i][0].equals(first_metre))) {
							samavftta = false;
						}
					}
					if (samavftta) {

						output.append("\n" + ("<br>The verse is in " + cm(first_tmp)
								+ " meter which is a samavṛtta.<br>"));

						for (int i = 0; i < 2; i++) {
							output.append("\n" + ("<br><b>Pāda " + (i + 1) + "..........\n</b>"));
							output.append("\n" + ("<br>Syllables &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;&nbsp;"
									+ metre_pada[i][2] + "\n"));
						}

						return first_metre;
						// metre_found=true;
					}
				}
				// check for anuztuB

				String pp1 = make_optional_regex("ytBrjm");
				String pp2 = make_optional_regex("ytBrnm");
				Pattern pat1 = Pattern.compile("^[lg]" + pp1 + pp2 + "[lg]$");
				Pattern pat2 = Pattern.compile("^[lg]" + pp1 + "lgl[lg]$");
				Matcher ma = pat1.matcher(metre_pada[0][3]);
				boolean isPres = true;
				if (!ma.find()) {
					isPres = false;
				}
				ma = pat2.matcher(metre_pada[1][3]);
				if (!ma.find()) {
					isPres = false;
				}

				if (isPres) {
					output.append("\n"
							+ "<br>The verse is in <b><font color=\"blue\">anuṣṭubh2</font></b> meter which is a samavṛtta.\n");

					for (int i = 0; i < 2; i++) {
						output.append("\n" + "<br><br><b>Pāda " + (i + 1) + "..........</b>");
						output.append("\n" + "<br>Syllables &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;&nbsp;"
								+ metre_pada[i][2] + "\n");
					}

					return "anuzwuB";
					// metre_found=true;
				}
				loop_ar: for (int i = 1; i < numSyllable1; i++) {
					int syl_pada1 = i;
					int syl_pada2 = numSyllable1 - i;
					int start = 0;
					int numSyllable = 0;
					for (int pada = 0; pada < 2; pada++) {// 4 padas //??? 2
															// padas for
															// ardhasama is
															// remaining
						if (pada % 2 == 0) {
							numSyllable = syl_pada1;
						} else {
							numSyllable = syl_pada2;
						}
						metre_pada[pada] = find_metre_pada(lenSyl, syllables, numSyllable, start);
						start += numSyllable;
					}
					for (int pada = 0; pada < 2; pada++) {
						if (metre_pada[pada][3].equals("t")) {
							metre_pada[pada][1] += "." + find_optional(metre_pada[pada][1]);
						}
					}
					String first_metre = metre_pada[0][1];
					String second_metre = metre_pada[1][1];
					// System.out.println(first_metre+" "+second_metre);
					if (equates(metre_pada[2][1], first_metre)) {
						String metre_here[] = find_metre_ardha(first_metre + " " + second_metre);
						if (metre_here[0].length() > 0) {
							output.append("\n"
									+ ("<br>The verse is in " + metre_here[1] + " meter which is a arDasamavftta.\n"));

							for (int ii = 0; ii < 2; ii++) {
								output.append("\n" + ("<br><br>......Pāda " + (ii + 1) + ":::::::::\n"));
								output.append("\n" + ("<br>Syllables &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;&nbsp;"
										+ metre_pada[ii][2] + "\n"));
							}

							// + metre_here[0]
							// +" with patterns "+metre_here[1]);

							return metre_here[1];
						}
					}
				}
			}
			return "none_found";
		}
		int numSyllable2 = regexChecker("[yvrlYmNRnJBGQDjbgqdKPCWTcwtkpSzsh]*[aAiIuUfFxXeEoO][HM]*", secondLine);

		int len_line2 = secondLine.length();
		int chars = 0;
		int lenSyl[] = new int[numSylVerse];
		for (int i = 0; i < numSyllable1; i++) {
			lenSyl[i] = syllables[i].length();
			chars += lenSyl[i];
		}
		if (chars < len_line1) {
			syllables[numSyllable1 - 1] += firstLine.substring(chars);
			chars = len_line1;
			lenSyl[numSyllable1 - 1] += len_line1 - chars;
		}
		for (int i = numSyllable1; i < numSylVerse; i++) {
			lenSyl[i] = syllables[i].length();
			chars += lenSyl[i];
		}
		if (chars < len_line1 + len_line2) {
			syllables[numSylVerse - 1] += secondLine.substring(chars - len_line1);
			chars = len_line1 + len_line2;
			lenSyl[numSylVerse - 1] += len_line1 + len_line2 - chars;
		}

		// the first case: that every pada has the same number of syllables
		String metre_pada[][] = new String[4][4];// 4 different metres for each
		// pada, 3 strings,
		// metre_name, gana_pattern,
		// the output and the
		// weights
		//boolean metre_found = false;
		if (numSyllable1 == numSyllable2) {
			// Thus both the lines have the same number of syllables
			if (numSyllable1 % 2 == 0) {// even number of syllables
				int numSyllable = numSylVerse / 4;
				for (int pada = 0; pada < 4; pada++) {// 4 padas
					int start = numSyllable * pada;
					metre_pada[pada] = find_metre_pada(lenSyl, syllables, numSyllable, start);
					// System.out.println("pada " + pada + " " +
					// metre_pada[pada][2]+"\nmetre_name..."+metre_pada[pada][0]+"\n");
				}
				boolean samavftta = true;
				for (int i = 0; i < 4; i++) {
					if (metre_pada[i][0].length() == 0) {
						samavftta = false;
					}
				}
				if (samavftta) {
					// atleast some meter found for all padas
					String first_metre = metre_pada[0][0];
					String metre_tmp = cm(s2r(first_metre));
					// String first_tem=s2r();
					// System.out.println(first_metre+"..."+first_metre);
					for (int i = 1; i < 4; i++) {
						if (!(metre_pada[i][0].equals(first_metre))) {
							samavftta = false;
						}
					}
					if (samavftta) {
						output.append("\n" + ("<br>The verse is in "+ metre_tmp
								+ " meter which is a samavṛtta.\n"));

						for (int i = 0; i < 4; i++) {
							output.append("\n" + ("<br><br><b>Pāda " + (i + 1) + "..........\n</b></b>"));
							output.append("\n" + ("<br>Syllables&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;&nbsp;"
									+ metre_pada[i][2] + "\n"));
						}

						return first_metre;
						//metre_found=true;
					}
				}
				// check for anuztuB

				String pp1 = make_optional_regex("ytBrjm");
				String pp2 = make_optional_regex("ytBrnm");
				Pattern pat1 = Pattern.compile("^[lg]" + pp1 + pp2 + "[lg]$");
				Pattern pat2 = Pattern.compile("^[lg]" + pp1 + "lgl[lg]$");
				Matcher ma = pat1.matcher(metre_pada[0][3]);
				boolean isPres = true;
				if (!ma.find()) {
					isPres = false;
				} // System.out.println("218");}
				ma = pat1.matcher(metre_pada[2][3]);
				if (!ma.find()) {
					isPres = false;
				} // System.out.println("220");}
				ma = pat2.matcher(metre_pada[1][3]);
				if (!ma.find()) {
					isPres = false;
				} // System.out.println(metre_pada[1][3]+"222");}
				ma = pat2.matcher(metre_pada[3][3]);
				if (!ma.find()) {
					isPres = false;
				} // System.out.println(metre_pada[3][3]+"224");}
				if (isPres) {
					//metre_found = true;
					output.append("\n" + ("<br>The verse is in <font color=blue><b>anuṣṭubh3 </b></font>meter which is a samavṛtta.\n"));

					for (int i = 0; i < 4; i++) {
						output.append("\n" + ("<br><br><b>Pāda " + (i + 1) + "..........\n</b>"));
						output.append("\n" + ("<br>Syllables&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;&nbsp;"
								+ metre_pada[i][2] + "\n"));
					}

					return "anuzwuB";
					// metre_found=true;
				}
			}

			// general loop to change the number of syllables and search for the
			// pattern in files in arDasamavftta
			loop_ar: for (int i = 1; i < numSyllable1; i++) {
				int syl_pada1 = i;
				int syl_pada2 = numSyllable1 - i;
				int start = 0;
				int numSyllable = 0;
				for (int pada = 0; pada < 4; pada++) {// 4 padas
					if (pada % 2 == 0) {
						numSyllable = syl_pada1;
					} else {
						numSyllable = syl_pada2;
					}
					metre_pada[pada] = find_metre_pada(lenSyl, syllables, numSyllable, start);
					start += numSyllable;
				}
				for (int pada = 0; pada < 4; pada++) {
					if (metre_pada[pada][3].equals("t")) {
						metre_pada[pada][1] += "." + find_optional(metre_pada[pada][1]);
					}
				}
				String first_metre = metre_pada[0][1];
				String second_metre = metre_pada[1][1];
				// System.out.println(first_metre+" "+second_metre);
				if (equates(metre_pada[2][1], first_metre)) {
					if (equates(metre_pada[3][1], second_metre)) {
						String metre_here[] = find_metre_ardha(first_metre + " " + second_metre);
						if (metre_here[0].length() > 0) {
							String metre_tmp = s2r(metre_here[1]);
							output.append("\n" + ("<br>The verse is in " + cm(s2r(metre_tmp))
									+ " meter which is an ardhasama.\n")); // ???
																						// ardhasama
																						// to
																						// be
																						// done

							for (int ii = 0; ii < 4; ii++) {
								output.append("\n" + ("<br><br><b>Pāda " + (ii + 1) + "..........</b>\n"));
								output.append("\n" + ("<br>Syllables&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;&nbsp;"
										+ metre_pada[ii][2] + "\n"));
							}
							// System.out.println("The verse is in arDasamavftta
							// metre pattern "
							// + metre_here[0]
							// +" with patterns "+metre_here[1]);

							return metre_here[1];
							// metre_found=true;
							// break loop_ar;
						}
					}
				}
			}
		}
		// general loop to change the number of syllables and search for the
		// pattern in files in vizamavftta
		int syl_pada[] = new int[4];
		loop_viz: for (int i = 1; i < numSyllable1; i++) {
			syl_pada[0] = i;
			syl_pada[1] = numSyllable1 - i;
			for (int j = 1; j < numSyllable2; j++) {
				syl_pada[2] = j;
				syl_pada[3] = numSyllable2 - j;
				int start = 0;
				int numSyllable = 0;
				for (int pada = 0; pada < 4; pada++) {
					numSyllable = syl_pada[pada];
					metre_pada[pada] = find_metre_pada(lenSyl, syllables, numSyllable, start);
					start += numSyllable;
				}
				for (int pada = 0; pada < 4; pada++) {
					if (metre_pada[pada][3].equals("t")) {
						metre_pada[pada][1] += "|" + find_optional(metre_pada[pada][1]);
					}
				}
				String pat_to_search = metre_pada[0][1];
				String syl_pat = syl_pada[0] + "";
				for (int pada = 1; pada < 4; pada++) {
					pat_to_search += " " + metre_pada[pada][1];
					syl_pat += " " + syl_pada[pada];
				}

				String metre_here[] = find_metre_vizama(pat_to_search);
				if (metre_here[0].length() > 0) {
					output.append("\n" + ("<br>The verse is in " + metre_here[1] + " meter which is a vizamavftta.\n"));

					for (int ii = 0; ii < 4; ii++) {
						output.append("\n" + ("<br><br><b>Pāda " + (ii + 1) + "..........</b>\n"));
						output.append("\n" + ("<br>Syllables &nbsp;&nbsp;&nbsp;&nbsp;&nbsp:&nbsp;&nbsp;"
								+ metre_pada[ii][2] + "\n"));
					}

					return metre_here[1];
					// metre_found=true;
					// break loop_viz;
				}
			}
		}
		// general loop to change the number of syllables and search for the
		// pattern in files in upajAti
		// int syl_pada[]=new int[4];
		loop_upaj: for (int i = 1; i < numSyllable1; i++) {
			syl_pada[0] = i;
			syl_pada[1] = numSyllable1 - i;
			for (int j = 1; j < numSyllable2; j++) {
				syl_pada[2] = j;
				syl_pada[3] = numSyllable2 - j;
				int start = 0;
				int numSyllable = 0;
				for (int pada = 0; pada < 4; pada++) {
					numSyllable = syl_pada[pada];
					metre_pada[pada] = find_metre_pada(lenSyl, syllables, numSyllable, start);
					start += numSyllable;
				}
				for (int pada = 0; pada < 4; pada++) {
					if (metre_pada[pada][3].equals("t")) {
						metre_pada[pada][1] += "|" + find_optional(metre_pada[pada][1]);
					}
				}
				String pat_to_search = metre_pada[0][1];
				String syl_pat = syl_pada[0] + "";
				for (int pada = 1; pada < 4; pada++) {
					pat_to_search += " " + metre_pada[pada][1];
					syl_pat += " " + syl_pada[pada];
				}
				// System.out.println(syl_pat+":::::"+pat_to_search);
				String metre_here[] = find_metre_upajAti(pat_to_search);
				String metre_tmp = metre_here[1];
				if (metre_here[0].length() > 0) {
					output.append("\n" + ("<br>The verse is in " + cm(s2r(metre_tmp)) + " meter which is an upajāti.\n"));

					for (int ii = 0; ii < 4; ii++) {
						output.append("\n" + ("<br><br><b>Pāda " + (ii + 1) + "..........</b>\n"));
						output.append("\n" + ("<br>Syllables &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;&nbsp;"
								+ metre_pada[ii][2] + "\n"));
					}
					
					return metre_here[1];
					// metre_found=true;
					// break loop_upaj;
				}
			}
		}

		// Now using the matras to find the meter ..ArDas
		String pat_pada[] = new String[2];
		pat_pada[0] = find_arya_ardha(lenSyl, syllables, numSyllable1, 0);
		pat_pada[1] = find_arya_ardha(lenSyl, syllables, numSyllable2, numSyllable1);

		if ((pat_pada[0].length() > 0) && (pat_pada[1].length() > 0)) {

			String metre_here[] = find_metre_arya(pat_pada[0] + " " + pat_pada[1]);
			if (metre_here[0].length() > 0) {
				String metre_tmp = metre_here[1];
				//metre_found = true;
				output.append("\n" + (output_print + "<br><br>The verse is in " + cm(s2r(metre_tmp))
						+ " meter which is a matravṛtta (āryā type).<br>"));
			} else {
				output.append("<br>Meter not found;");
			}
			output.append("\n" + ("<br><b>Ardha 1.........&nbsp;</b>"));
			output.append("\n" + ("<br>Syllables :&nbsp;"));
			for (int i = 0; i < numSyllable1; i++) {
				output.append(syllables[i] + " ");
			}

			output.append("<br>Weights &nbsp;&nbsp;:&nbsp;");

			boolean weight[] = new boolean[numSylVerse];
			for (int i = 0; i < numSylVerse; i++) {
				String syl = syllables[i];
				output_print += (syl + " ");
				int vowel_ind = find_vowel_ind(syl);
				int cons_here = syl.length() - 1 - vowel_ind;
				char vowel = syl.charAt(vowel_ind);
				char last_char = syl.charAt(syl.length() - 1);
				String long_vowels = "AIUeEoOF";
				if (long_vowels.indexOf(vowel) != -1) {
					weight[i] = false;
				} else {
					if (i == numSylVerse - 1) {
						String guru_cons = "MHm";
						if (guru_cons.indexOf(last_char) != -1) {
							weight[i] = false;
						} else {
							weight[i] = true;
						}
					} else if (i + 1 < numSylVerse) {
						int vowel_ind_next = find_vowel_ind(syllables[i + 1]) + cons_here;
						if (vowel_ind_next >= 2) {
							weight[i] = false;
						} // conjunct consonant
						else {
							weight[i] = true;
						}
					}
				}
			}

			for (int i = 0; i < numSyllable1 - 1; i++) {
				output.append(coloring(out_weight(weight[i])) + " ");

			}
			output.append(coloring("g"));// for last syllable
			int sum1 = 0;
			for (int i = 0; i < numSyllable1 - 1; i++) {
				if (out_weight(weight[i]) == "l") {
					sum1 = sum1 + 1;
				} else {
					sum1 = sum1 + 2;
				}

			}
			sum1 += 2;
			output.append("<br>Matras &nbsp;&nbsp;&nbsp;:&nbsp;" + sum1); // +2
																			// for
																			// last
																			// guru

			output.append("\n" + ("<br><br><b>Ardha 2.........&nbsp;</b>"));
			output.append("\n" + ("<br>Syllables :&nbsp;"));
			for (int i = numSyllable1; i < numSylVerse; i++) {
				output.append(syllables[i] + " ");
			}
			output.append("<br>Weights &nbsp;&nbsp;:&nbsp;");
			for (int i = numSyllable1; i < numSylVerse - 1; i++) {
				output.append(coloring(out_weight(weight[i])) + " ");
			}
			output.append(coloring("g")); // for last syllable
			int sum2 = 0;
			for (int i = numSyllable1; i < numSylVerse - 1; i++) {
				if (out_weight(weight[i]) == "l") {
					sum2 = sum2 + 1;
				} else {
					sum2 = sum2 + 2;
				}

			}
			sum2 += 2;
			output.append("<br>Matras &nbsp;&nbsp;&nbsp;:&nbsp;" + sum2);// +2
																			// for
																			// last
																			// guru

			return metre_here[1];

		}
		return "none_found";
		// if(!metre_found){
		// System.out.println("no registered pattern found in the input verse.
		// The database is being updated. Please check for any error in the
		// input.");
		// fr.write("none_found\n");
		// }

	}

	public String find_optional(String gana_pattern) {
		return gana_pattern.substring(0, gana_pattern.length() - 1) + "l";
	}

	public boolean equates(String s1, String s2) {
		if (s1.equals(s2)) {
			return true;
		}
		String tmp1[] = s1.trim().split("[|]");
		String tmp2[] = s2.trim().split("[|]");
		for (int i = 0; i < tmp1.length; i++) {
			for (int j = 0; j < tmp2.length; j++) {
				if (tmp1[i].equals(tmp2[j])) {
					return true;
				}
			}
		}
		return false;
	}

	public String make_optional_regex(String pattern) {
		String out = "";
		for (int i = 0; i < pattern.length(); i++) {
			char search = pattern.charAt(i);
			switch (search) {
			case 'y':
				out += "lgg|";
				break;
			case 'r':
				out += "glg|";
				break;
			case 't':
				out += "ggl|";
				break;
			case 'B':
				out += "gll|";
				break;
			case 'j':
				out += "lgl|";
				break;
			case 's':
				out += "llg|";
				break;
			case 'n':
				out += "lll|";
				break;
			case 'm':
				out += "ggg|";
				break;
			default:
				break;
			}
		}
		out = out.substring(0, out.length() - 1);

		return "(" + out + ")";
	}

	public String make_regex_matra(String pattern, boolean optional_vA) {
		String out = "^";
		for (int i = 0; i < pattern.length(); i++) {
			char search = pattern.charAt(i);
			switch (search) {
			case 'G':
				out += "(gg)";
				break;
			case 'B':
				out += "(gll)";
				break;
			case 'j':
				out += "(lgl)";
				break;
			case 's':
				out += "(llg)";
				break;
			case 'L':
				out += "(llll)";
				break;
			case 'S':
				out += "(gg|llg)";
				break;
			case 'b':
				out += "(gg|gll)";
				break;
			case 'h':
				out += "(lgl|llll)";
				break;
			case 'J':
				out += "(gg|gll|llg|llll)";
				break;
			case '4':
				out += "(gg|gll|llg|lgl|llll)";
				break;
			default:
				out += "(" + search + ")";
				break;
			}
		}
		if (optional_vA) {
			if (out.substring(out.length() - 3).equals("(g)")) {
				out = out.substring(0, out.length() - 3) + "(l|g$)";
			}
		}
		return out;
	}

	public String[] find_metre_pada(int lenSyl[], String syllables[], int numSyllable, int start) {
		String metre_pada = "";
		String gana_pattern = "";
		String output_print = "";
		String vA_applied = "f";
		String out_weights = "";
		boolean weight[] = new boolean[numSyllable];
		for (int i = 0; i < numSyllable; i++) {
			String syl = syllables[start + i];
			output_print += (syl + " ");
			int vowel_ind = find_vowel_ind(syl);
			int cons_here = syl.length() - 1 - vowel_ind;
			char vowel = syl.charAt(vowel_ind);
			char last_char = syl.charAt(syl.length() - 1);
			String long_vowels = "AIUFeEoO";
			if (long_vowels.indexOf(vowel) != -1) {
				weight[i] = false;
			} else {
				if (i == numSyllable - 1) {
					String guru_cons = "MHm";
					if (guru_cons.indexOf(last_char) != -1) {
						weight[i] = false;
					} else {
						weight[i] = true;
					}
				} else if (start + i + 1 < numSylVerse) {
					int vowel_ind_next = find_vowel_ind(syllables[start + i + 1]) + cons_here;
					if (vowel_ind_next >= 2) {
						weight[i] = false;
					} // conjunct consonant
					else {
						weight[i] = true;
					}
				}
			}
		}
		int numGroups = numSyllable / 3;
		if (numSyllable % 3 != 0) {
			numGroups++;
		}
		String sylGroup[][] = new String[numGroups][3];
		boolean wtGroup[][] = new boolean[numGroups][3];
		for (int i = 0; i < numGroups; i++) {
			sylGroup[i][0] = syllables[start + 3 * i];
			wtGroup[i][0] = weight[3 * i];
			if (3 * i + 1 < numSyllable) {
				sylGroup[i][1] = syllables[start + 3 * i + 1];
				wtGroup[i][1] = weight[3 * i + 1];
			}
			if (3 * i + 2 < numSyllable) {
				sylGroup[i][2] = syllables[start + 3 * i + 2];
				wtGroup[i][2] = weight[3 * i + 2];
			}
		}

		String gana[] = new String[numGroups];
		boolean isFull = false;
		if (numSyllable % 3 == 0) {
			isFull = true;
		}
		if (!isFull) {
			for (int i = 0; i < numGroups - 1; i++) {
				gana[i] = gana_name(wtGroup[i]);
				// System.out.print(gana[i]+" ");
			}
			gana[numGroups - 1] = out_weight(wtGroup[numGroups - 1][0]);
			if (numSyllable % 3 > 1)
				gana[numGroups - 1] += out_weight(wtGroup[numGroups - 1][1]);
		} else {
			for (int i = 0; i < numGroups; i++) {
				gana[i] = gana_name(wtGroup[i]);
				// System.out.print(gana[i]+" ");
			}
		}
		String metre_type = find_metre_sama(gana);
		metre_pada = metre_type;
		@SuppressWarnings("unused")
		String backup_metre = metre_type;
		// metre_pada[pada]=
		String backup = "";
		// if(metre_type.length()>0){

		backup += ("<br>Weights &nbsp;&nbsp&nbsp;&nbsp&nbsp;&nbsp&nbsp;:&nbsp;&nbsp;");
		String color = new String();
		for (int i = 0; i < numSyllable; i++) {
			color += (out_weight(weight[i]) + "  ");
			out_weights += out_weight(weight[i]);

		}
		color = color.replace("l", "<font color=#053BFC>l</font>").replace("g", "<font color=red>g</font>");
		backup += color;

		// for (int i = 0; i < numSyllable; i++) {
		// backup += (out_weight(weight[i]) + " ");
		// out_weights += out_weight(weight[i]);

		// }

		backup += ("<br>Ganas &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;&nbsp;");
		for (int i = 0; i < numGroups - 1; i++) {
			backup += (gana[i] + " ");
			gana_pattern += gana[i];
		}

		if (!isFull) {
			for (int i = 0; i < 2; i++) {
				if (sylGroup[numGroups - 1][i] != null) {
					backup += (out_weight(wtGroup[numGroups - 1][i]) + " ");
					gana_pattern += out_weight(wtGroup[numGroups - 1][i]);
				}
			}
		} else {
			backup += (gana[numGroups - 1] + " ");
			gana_pattern += gana[numGroups - 1];
		}
		backup += "\n";

		backup += ("<br>Syllable count :&nbsp;&nbsp;" + numSyllable);
		//backup += "<br><br>";
		boolean vA_pada_applied = false;

		// Applying vA padante

		if (weight[numSyllable - 1]) {
			weight[numSyllable - 1] = false;
			for (int i = numGroups - 1; i < numGroups; i++) {
				// System.out.println(i+"..."+numSyllable);
				if (3 * i + 3 == numSyllable) {
					wtGroup[i][2] = weight[3 * i + 2];
					gana[i] = gana_name(wtGroup[i]);
					// System.out.println(gana[i]);
				}
				// sylGroup[i][0]=syllables[3*i];
				// wtGroup[i][0]=weight[3*i];
				else {
					if (3 * i + 1 <= numSyllable) {
						sylGroup[i][0] = syllables[3 * i];
						wtGroup[i][0] = weight[3 * i];
						if (wtGroup[i][0])
							gana[numGroups - 1] = "l";
						else
							gana[numGroups - 1] = "g";
					}
					if (3 * i + 2 <= numSyllable) {
						sylGroup[i][1] = syllables[3 * i + 1];
						wtGroup[i][1] = weight[3 * i + 1];
						if (wtGroup[i][1])
							gana[numGroups - 1] += "l";
						else
							gana[numGroups - 1] += "g";
					}
				}
			}

			String pos_g_pat = "";
			for (int i = 0; i < numGroups; i++) {
				pos_g_pat += gana[i];
			}
			// gana_pattern.substring(0,gana_pattern.length()-1)+gana[numGroups-1];//we
			// will check vA condition on this pattern
			metre_type = find_metre_sama(gana);
			// if(metre_type.length()>0){
			boolean is_optional = find_va(pos_g_pat);
			// System.out.println(pos_g_pat+"..."+is_optional);
			if (is_optional) {
				gana_pattern = "";
				vA_applied = "t";
				metre_pada = metre_type;
				vA_pada_applied = true;
				output_print += ("\n");
				String color2 = "";
				output_print += ("<br>Weights &nbsp;&nbsp&nbsp;&nbsp&nbsp;&nbsp&nbsp;:&nbsp;&nbsp;");
				for (int i = 0; i < numSyllable; i++) {
					color2 += (out_weight(weight[i]) + "  ");
				}
				color2 = color2.replace("l", "<font color=#053BFC>l</font>").replace("g", "<font color=red>g</font>");
				output_print += color2;
				output_print += ("<br>Ganas &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;&nbsp;");
				for (int i = 0; i < numGroups - 1; i++) {
					output_print += (gana[i] + " ");
					gana_pattern += gana[i];
				}
				if (!isFull) {
					for (int i = 0; i < 2; i++) {
						if (sylGroup[numGroups - 1][i] != null) {
							output_print += (out_weight(wtGroup[numGroups - 1][i]) + " ");
							gana_pattern += out_weight(wtGroup[numGroups - 1][i]);
						}
					}
				} else {
					output_print += (gana[numGroups - 1] + " ");
					gana_pattern += gana[numGroups - 1];
				}
				output_print += "\n";

				output_print += ("<br>Syllable count :&nbsp;&nbsp;" + numSyllable);
				//output_print += "<br><br>";
			}

		}
		if (!vA_pada_applied) {
			output_print += (backup);
		}
		// output_print += "hari";
		String output[] = { metre_pada, gana_pattern, output_print, out_weights, vA_applied };
		return output;
	}

	@SuppressWarnings("unused")
	public String find_arya_ardha(int lenSyl[], String syllables[], int numSyllable, int start) {
		// String metre_pada = "";
		// String gana_pattern = "";
		String output_print = "";
		// String vA_applied = "f";
		boolean weight[] = new boolean[numSyllable];
		for (int i = 0; i < numSyllable; i++) {
			String syl = syllables[start + i];
			output_print += (syl + " ");
			int vowel_ind = find_vowel_ind(syl);
			int cons_here = syl.length() - 1 - vowel_ind;
			char vowel = syl.charAt(vowel_ind);
			char last_char = syl.charAt(syl.length() - 1);
			String long_vowels = "AIUeEoOF";
			if (long_vowels.indexOf(vowel) != -1) {
				weight[i] = false;
			} else {
				if (i == numSyllable - 1) {
					String guru_cons = "MHm";
					if (guru_cons.indexOf(last_char) != -1) {
						weight[i] = false;
					} else {
						weight[i] = true;
					}
				} else if (start + i + 1 < numSylVerse) {
					int vowel_ind_next = find_vowel_ind(syllables[start + i + 1]) + cons_here;
					if (vowel_ind_next >= 2) {
						weight[i] = false;
					} // conjunct consonant
					else {
						weight[i] = true;
					}
				}
			}
		}
		String this_line = "";
		for (int i = 0; i < numSyllable; i++) {
			this_line = this_line + out_weight(weight[i]);
		}
		String output = "";
		for (int i = 0; i < num_matra_regex; i++) {
			Pattern matra_pat = Pattern.compile(matra_regex[i]);
			Matcher m = matra_pat.matcher(this_line);
			// System.out.println(this_line);
			if (m.find()) {
				// int all_groups=m.groupCount();
				// String
				output = output + " " + matra_pat_all[i];
			}

		}
		return output.trim().replace(" ", "|");

	}

	public boolean find_va(String gana_pattern) {
		for (int i = 0; i < numPatterns; i++) {
			if (pats[i].equals(gana_pattern)) {
				return true;
			}
		}
		return false;
	}

	public String find_metre_sama(String[] gana) {
		String pat = "";
		for (int i = 0; i < gana.length; i++) {
			if (i == 0) {
				pat = gana[i];
			} else {
				pat = pat + "" + gana[i];
			}
		}
		String output = "";
		loop: for (int i = 0; i < sama_entered; i++) {
			if (pat.equals(sama_pat[i])) {
				output = sama_name[i];
				break loop;
			} else {
				output = "";
			}

		}
		return output;
	}

	public int find_vowel_ind(String syl) {
		String all_vowels = "aAiIuUfFxeEoO";
		for (int i = 0; i < syl.length(); i++) {
			if (all_vowels.indexOf(syl.charAt(i)) != -1) {
				return i;
			}
		}
		output.append("<br>Error...no vowel in this syllable " + syl);
		return -1;
	}

	public String[] find_metre_ardha(String pattern) {
		String tmp[] = pattern.split(" ");
		String tmp1[][] = new String[tmp.length][2];
		for (int i = 0; i < tmp.length; i++) {
			if (tmp[i].indexOf(".") != -1) {
				tmp1[i] = tmp[i].split("[.]");
			} else {
				tmp1[i][0] = tmp[i];
			}
		}
		String pat = "";
		for (int i = 0; i < 2; i++) {
			if (tmp1[0][i] != null) {
				pat = tmp1[0][i];
				for (int j = 0; j < 2; j++) {
					if (tmp1[1][j] != null) {
						pat = pat + " " + tmp1[1][j];
						for (int it = 0; it < ardh_entered; it++) {
							if (ardha_pat[it].equals(pat)) {
								String output[] = { pat, ardha_metre[it] };
								return output;
							}
						}
					}
				}
			}
		}
		String output1[] = { "", "" };
		return output1;
	}

	public String[] find_metre_arya(String pattern) {
		// output.append("<br>Pattern is ");
		String tmp[] = pattern.split(" ");
		String tmp1[][] = new String[tmp.length][2];
		for (int i = 0; i < tmp.length; i++) {
			if (tmp[i].indexOf("|") != -1) {
				tmp1[i] = tmp[i].split("[|]");
			} else {
				tmp1[i][0] = tmp[i];
			}
		}
		String pat = "";
		for (int i = 0; i < 2; i++) {
			if (tmp1[0][i] != null) {
				pat = tmp1[0][i];
				for (int j = 0; j < 2; j++) {
					if (tmp1[1][j] != null) {
						pat = pat + " " + tmp1[1][j];
						// System.out.println("loop:::"+pat);
						for (int it = 0; it < arya_entered; it++) {
							if (arya_pat[it].equals(pat)) {
								String output[] = { pat, arya_metre[it] };
								return output;
							}
						}
					}
				}
			}
		}
		String output1[] = { "", "" };
		return output1;
	}

	public String[] find_metre_vizama(String pattern) {
		String tmp[] = pattern.split(" ");

		String tmp1[][] = new String[tmp.length][2];
		for (int i = 0; i < tmp.length; i++) {
			if (tmp[i].indexOf("|") != -1) {
				tmp1[i] = tmp[i].split("[|]");
			} else {
				tmp1[i][0] = tmp[i];
			}
		}
		String pat = "";
		for (int i = 0; i < 2; i++) {
			if (tmp1[0][i] != null) {
				pat = tmp1[0][i];
				for (int j = 0; j < 2; j++) {
					if (tmp1[1][j] != null) {
						pat = pat + " " + tmp1[1][j];
						for (int k = 0; k < 2; k++) {
							if (tmp1[2][k] != null) {
								pat = pat + " " + tmp1[2][k];
								for (int l = 0; l < 2; l++) {
									if (tmp1[3][l] != null) {
										pat = pat + " " + tmp1[3][l];
										for (int it = 0; it < visama_entered; it++) {
											if (visama_pat[it].equals(pat)) {
												String output[] = { pat, visama_metre[it] };
												return output;
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
		String output1[] = { "", "" };
		return output1;
	}

	public String[] find_metre_upajAti(String pattern) {
		String tmp[] = pattern.split(" ");

		String tmp1[][] = new String[tmp.length][2];
		for (int i = 0; i < tmp.length; i++) {
			if (tmp[i].indexOf("|") != -1) {
				tmp1[i] = tmp[i].split("[|]");
			} else {
				tmp1[i][0] = tmp[i];
			}
		}
		String pat = "";
		for (int i = 0; i < 2; i++) {
			if (tmp1[0][i] != null) {
				pat = tmp1[0][i];
				for (int j = 0; j < 2; j++) {
					if (tmp1[1][j] != null) {
						pat = pat + " " + tmp1[1][j];
						for (int k = 0; k < 2; k++) {
							if (tmp1[2][k] != null) {
								pat = pat + " " + tmp1[2][k];
								for (int l = 0; l < 2; l++) {
									if (tmp1[3][l] != null) {
										pat = pat + " " + tmp1[3][l];
										for (int it = 0; it < upajAti_entered; it++) {
											if (upajati_pat[it].equals(pat)) {
												String output[] = { pat, upajati_metre[it] };
												return output;
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
		String output1[] = { "", "" };
		return output1;
	}

	public String out_weight(boolean weight) {
		if (weight) {
			return "l"; 
		} else {
			return "g";
		}

	}
	public String coloring (String st){
		if (st.equals("l")){
			st=st.replace("l", "<font color=\"blue\">l</font>");
		} else if (st.equals("g")){
			st=st.replace("g", "<font color=red>g</font>");
		}
		return st;
	}
	public String cm (String st){
		return "<b><font color=blue>"+st+"</font></b>";
	}

	public String gana_name(boolean[] weight) {
		String pat = "";
		for (int i = 0; i < weight.length; i++) {
			pat = pat + out_weight(weight[i]);
		}
		String output = "";
		loop: for (int i = 0; i < 8; i++) {
			if (pat.equals(gana_pat[i])) {
				output = gana_name[i];
				break loop;
			}
		}
		if (output.length() == 0) {
			output = output + " <br>:For this pattern no metre is found"; // ("For
																			// the
																			// pattern
																			// "+pat+"
																			// nothing
																			// found");
		}
		return output;
	}

	public int regexChecker(String theRegex, String str2Check) {
		int numSyl = 0;
		// You define your regular expression (REGEX) using Pattern

		Pattern checkRegex = Pattern.compile(theRegex);

		// Creates a Matcher object that searches the String for
		// anything that matches the REGEX

		Matcher regexMatcher = checkRegex.matcher(str2Check);

		// Cycle through the positive matches and print them to screen
		// Make sure string isn't empty and trim off any whitespace
		// Please note that we need numSyl for one line and numSyllable for the
		// complete verse
		while (regexMatcher.find()) {
			if (regexMatcher.group().length() != 0) {
				syllables[numSylVerse] = regexMatcher.group().trim();
				// System.out.print( regexMatcher.group().trim()+" " );
				// System.out.println(numSyl+" "+syllables[numSylVerse]);
				numSyl++;
				numSylVerse++;
				// You can get the starting and ending indexs

			}
		}

		// System.out.println();
		return numSyl;
	}

	public int[] sylInd(String theRegex, String str2Check, int numSyls) {
		int indices[] = new int[numSyls];
		int numSyl = 0;
		// You define your regular expression (REGEX) using Pattern
		int nextInd = 0;
		Pattern checkRegex = Pattern.compile(theRegex);

		// Creates a Matcher object that searches the String for
		// anything that matches the REGEX

		Matcher regexMatcher = checkRegex.matcher(str2Check);

		// Cycle through the positive matches and print them to screen
		// Make sure string isn't empty and trim off any whitespace
		// Please note that we need numSyl for one line and numSyllable for the
		// complete verse
		while (regexMatcher.find()) {
			int thisLen = regexMatcher.group().length();
			if (thisLen != 0) {
				indices[numSyl] = nextInd;
				nextInd += thisLen;
				syllables[numSylVerse] = regexMatcher.group().trim();
				// System.out.print( regexMatcher.group().trim()+" " );
				// System.out.println(numSyl+" "+syllables[numSylVerse]);
				numSyl++;
				numSylVerse++;
				// You can get the starting and ending indexs

			}
		}

		// System.out.println();
		return indices;
	}

	public void regexReplace(String str2Replace) {

		Pattern replace = Pattern.compile("\\s+");

		@SuppressWarnings("unused")
		Matcher regexMatcher = replace.matcher(str2Replace.trim());

	}

	public String s2r(String args) throws Exception {
		String out = "";
		out = args.replaceAll("K", "kh").replaceAll("G", "gh").replaceAll("N", "ṅ").replaceAll("C", "ch")
				.replaceAll("J", "jh").replaceAll("Y", "ñ").replaceAll("w", "ṭ").replaceAll("W", "ṭh")
				.replaceAll("q", "ḍ").replaceAll("Q", "ḍh").replaceAll("R", "ṇ").replaceAll("T", "th")
				.replaceAll("D", "dh").replaceAll("P", "ph").replaceAll("B", "bh").replaceAll("S", "ś")
				.replaceAll("z", "ṣ").replaceAll("A", "ā").replaceAll("I", "ī").replaceAll("U", "ū")
				.replaceAll("f", "ṛ").replaceAll("F", "ṝ").replaceAll("x", "ḷ").replaceAll("E", "ai")
				.replaceAll("O", "au").replaceAll("M", "ṃ").replaceAll("H", "ḥ");

		return out;
	}

	public String r2s(String args) throws Exception {
		String out = "";
		out = args.replaceAll("kh", "K").replaceAll("gh", "G").replaceAll("ṅ", "N").replaceAll("ch", "C")
				.replaceAll("jh", "J").replaceAll("ñ", "Y").replaceAll("ṭ", "w").replaceAll("ṭh", "W")
				.replaceAll("ḍ", "q").replaceAll("ḍh", "Q").replaceAll("ṇ", "R").replaceAll("th", "T")
				.replaceAll("dh", "D").replaceAll("ph", "P").replaceAll("bh", "B").replaceAll("ś", "S")
				.replaceAll("ṣ", "z").replaceAll("ā", "A").replaceAll("ī", "I").replaceAll("ū", "U")
				.replaceAll("ṛ", "f").replaceAll("ṝ", "F").replaceAll("ḷ", "x").replaceAll("ai", "E")
				.replaceAll("au", "O").replaceAll("ṃ", "M").replaceAll("ḥ", "H");

		return out;
	}
}
